"""A pypi demonstration vehicle.

.. moduleauthor:: Andrew Carter <andrew@invalid.com>

"""

import useful_1
import useful_2


def start():
    "This starts this module running ..."