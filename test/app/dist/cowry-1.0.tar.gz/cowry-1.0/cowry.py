class Cowry(object):
    """docstring for Foo."""
    def __init__(self):
        super().__init__()
        print("I am cowry")
