from distutils.core import setup
setup(name='cowry',
      version='1.0',
      py_modules=['cowry'],
      url="https://abc.com",
      author="aong",
      author_email="abc@qq.com"
      )
